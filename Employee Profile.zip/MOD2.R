install.packages("zip")
install.packages("readr")
#libraries
library(readr)
library(zip)

# Unzip the folder
unzip("C:/Users/Dell/OneDrive/Desktop/Employee_Profile.zip", exdir = "Employee_Profile_Unzipped")

list.files("C:/Users/Dell/OneDrive/Desktop/Employee_Profile/")

files <- list.files("Employee_Profile_Unzipped", full.names = TRUE)
for (file in files) {
  employee_data <- read.csv(file)
  print(employee_data)
}
